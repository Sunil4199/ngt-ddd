from pymongo import mongoclient
client = mongoclient('localhost:27017')
db = client.EmployeeData
def insert():
    try:
        
        
        employeeId = input('Enter Employee id :')
        employeeName = input('Enter Name :')
        employeeAge = input('Enter age :')
        employeeCountry =input('Enter Country :')
        
        db.Employees.insert_one(
        {
        "id": employeeId,
            "name":employeeName,
        "age":employeeAge,
        "country":employeeCountry
        })
        print("\nInserted data successfully\n")
    
    except Exception:
        print(str(e))


insert()
